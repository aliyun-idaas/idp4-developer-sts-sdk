//
//  NoPasswordLoginSDK.h
//  NoPasswordSDK
//
//  Created by 九州云腾 on 2018/12/14.
//  Copyright © 2018 九州云腾. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
typedef void (^SuccessBlock)(NSDictionary *resultDic);
typedef void (^FailureBlock)(NSDictionary *resultDic);
typedef void (^CompleteBlock)(BOOL success);
typedef void (^CLCompleteBlock)(NSDictionary *resultDic);
@interface NoPasswordLoginSDK : NSObject
/**
 * @brief 初始化接口.
 * @param IDPServerURL IDP地址.
 * @param appKey 公司的appKey.
 * @param appSercert 公司的appSercert.
 * @param enterpriseId 公司的enterpriseId.
 */
- (id)initWithIDPServerURL:(NSString *)IDPServerURL appKey:(NSString *)appKey appSercert:(NSString *)appSercert enterpriseId:(NSString *)enterpriseId;
/**
 * @brief U+P下载证书.
 * @param username 用户名.
 * @param pwd 密码.
 */
-(void)DownLoadCertificateByPwdWithUsername:(NSString *)username pwd:(NSString *)pwd success:(SuccessBlock )success failure:(FailureBlock )failure;
/**
 * @brief 指纹免密登录.
 */
-(void)FingerprintLoginWithSuccess:(SuccessBlock )success failure:(FailureBlock )failure;
/**
 * @brief 免密登录
 */
-(void)VertifyId_tokenWithSuccess:(SuccessBlock )success failure:(FailureBlock )failure;
/**
 * @brief 判断证书是否存在.
 */
+(BOOL)isExistCertificate;
/**
 * @brief u+p登录IDP
 * @param username 用户名.
 * @param password 密码.
 */
- (void)loginWthUsername:(NSString *)username password:(NSString *)password success:(SuccessBlock)completionBlock failure:(FailureBlock)failureBlock;
/**
 * @brief 注册账户
 * @param username 用户名.
 * @param password 密码.
 * @param email 邮箱.
 * @param phoneNumber 手机号.
 * @param enterpriseAuthId 认证源唯一标识.
 */
-(void)wxRegisterUserName:(NSString *)username password:(NSString *)password email:(NSString *)email phoneNumber:(NSString *)phoneNumber enterpriseAuthId:(NSString *)enterpriseAuthId success:(SuccessBlock)completionBlock failure:(FailureBlock)failureBlock;
/**
 * @brief 微信授权登录
 * @param openid 微信授权后返回的用户标识.
 * @param clientId OAuth2 clientId.
 * @param enterpriseAuthId 认证源唯一标识.
 */
-(void)wxquickAuthLoginWithUserInfo:(NSString *)openid clientId:(NSString *)clientId enterpriseAuthId:(NSString *)enterpriseAuthId success:(SuccessBlock)completionBlock failure:(FailureBlock)failureBlock;
/**
 * @brief 微信绑定IDaaS账户
 * @param idpUser 用户名.
 * @param idp_cred 密码.
 * @param userId 微信授权后返回的用户标识..
 * @param clientId OAuth2 clientId.
 * @param enterpriseAuthId 认证源唯一标识.
 * @param otherData 调用微信用户信息接口返回的用户信息集合(详情可以参考demo).
 */
-(void)wxBindingIDPAuthLoginWithUserName:(NSString *)idpUser idp_cred:(NSString *)idp_cred enterpriseAuthId:(NSString *)enterpriseAuthId userId:(NSString *)userId clientId:(NSString *)clientId otherData:(NSDictionary *)otherData success:(SuccessBlock)completionBlock failure:(FailureBlock)failureBlock;
@end

